#ifndef _WX_CHOICDLG_H_BASE_
#define _WX_CHOICDLG_H_BASE_

#if wxUSE_CHOICEDLG

#include "wx/generic/choicdgg.h"

#endif

#endif
    // _WX_CHOICDLG_H_BASE_
