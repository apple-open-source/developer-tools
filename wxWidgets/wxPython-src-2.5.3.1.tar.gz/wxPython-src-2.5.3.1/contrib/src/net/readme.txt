Net library
===========

This is a library of email and other Internet-related functionality.

wxMailMessage		Populate this before sending a message
wxMapiSession       Encapsulates Simple MAPI functionality on Windows
wxEmail             Platform-independent mail functions, such as Send
wxWeb               Platform-independent web functions, such as OpenURL

