This is wxWidgets for Windows (wxMSW)
-------------------------------------

For information on installing wxWidgets, please see install.txt.

For further information, please see docs/html/index.htm and the
wxWidgets reference manual.

